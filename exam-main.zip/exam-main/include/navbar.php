<link rel="stylesheet" href="css/nav.css">
<div class="navbar">
        <div class="navbar-brand">
            <img src="images/simplondef.png" alt="">
        </div>
        <div id="link-group" class="link-group">
            <ul>
                <li class="nav-link"><a href="inscription.php"><span class="material-icons">Inscription</span>Inscription</a></li>
                <li class="nav-link"><a href="connexion.php"><span class="material-icons">Connexion</span>Connexion</a></li>

            </ul>
        </div>
        <div class="mobile-btn">
            <span onclick="menuOpen();" id="open" class="material-icons open">menu</span>
            <span onclick="menuClose();" id="close" c class="material-icons close">close</span>
        </div>
    </div>