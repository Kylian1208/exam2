<?php
{
    $dbh = new PDO('mysql:host=localhost;dbname=france;charset=utf8', 'root', '');
}
?>